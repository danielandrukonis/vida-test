# VidaApi.Profile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** | First name of the Uber user. | [optional] 
**lastName** | **String** | Last name of the Uber user. | [optional] 
**email** | **String** | Email address of the Uber user | [optional] 
**picture** | **String** | Image URL of the Uber user. | [optional] 
**promoCode** | **String** | Promo code of the Uber user. | [optional] 


