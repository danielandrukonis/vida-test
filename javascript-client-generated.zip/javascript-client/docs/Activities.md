# VidaApi.Activities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** | Position in pagination. | [optional] 
**limit** | **Number** | Number of items to retrieve (100 max). | [optional] 
**count** | **Number** | Total number of items available. | [optional] 
**history** | [**[Activity]**](Activity.md) |  | [optional] 


